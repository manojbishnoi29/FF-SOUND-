CRAFTLAND CUSTOM SFX PACK — README
===================================

In-game UID: 2284575373

Sounds in this pack:
- Asset 679001: free_fire_fanny_tone
- Asset 679002: Indila - Tourner Dans Le Vide (Slowed & Reverb)

Raw payload URLs (public GitHub repository):
679001 WebGL: https://raw.githubusercontent.com/manojbishnoi29/FF-SOUND-/refs/heads/arena/3449d202-ff-sound/679001/WebGL
679001 NotWebGL: https://raw.githubusercontent.com/manojbishnoi29/FF-SOUND-/refs/heads/arena/3449d202-ff-sound/679001/NotWebGL
679002 WebGL: https://raw.githubusercontent.com/manojbishnoi29/FF-SOUND-/refs/heads/arena/3449d202-ff-sound/679002/WebGL
679002 NotWebGL: https://raw.githubusercontent.com/manojbishnoi29/FF-SOUND-/refs/heads/arena/3449d202-ff-sound/679002/NotWebGL

Install: extract Store/ and 2284575373/ into
Android/data/com.dts.freefireth/files/Workshop/
For Free Fire MAX, use com.dts.freefiremax. Back up existing Workshop files first.
