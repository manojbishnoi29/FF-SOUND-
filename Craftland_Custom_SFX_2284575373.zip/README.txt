CRAFTLAND CUSTOM SFX PACK – README (Hinglish)
=============================================

In-game UID: 2284575373
Asset ID: 679001 (sound: free_fire_fanny_tone)

FOLDER STRUCTURE
----------------
Store/679001_1.bytes            <- resource descriptor
2284575373/ResourceIndex.bytes  <- UID index; folder name must stay unchanged
upload/679001/WebGL             <- hosted WebGL payload
upload/679001/NotWebGL          <- hosted Android/iOS payload

GITHUB RAW URLS
---------------
https://raw.githubusercontent.com/manojbishnoi29/FF-SOUND-/refs/heads/arena/3449d202-ff-sound/679001/WebGL
https://raw.githubusercontent.com/manojbishnoi29/FF-SOUND-/refs/heads/arena/3449d202-ff-sound/679001/NotWebGL

The repository must be public. The descriptor in this archive already points to these URLs.

PHONE INSTALL
-------------
Copy Store/ and 2284575373/ to:
Android/data/com.dts.freefireth/files/Workshop/
For Free Fire MAX: Android/data/com.dts.freefiremax/files/Workshop/
Back up existing files first. This pack replaces the old sound set; it does not merge with it.
